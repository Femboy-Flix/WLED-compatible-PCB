G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*
G04 #@! TF.CreationDate,2026-06-13T12:52:09+02:00*
G04 #@! TF.ProjectId,W-LED,572d4c45-442e-46b6-9963-61645f706362,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-06-13 12:52:09*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
%AMOutline5P*
0 Free polygon, 5 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 5*
0 $1 to $10 corner X, Y*
0 $11 Rotation angle, in degrees counterclockwise*
0 create outline with 5 corners*
4,1,5,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$1,$2,$11*%
%AMOutline6P*
0 Free polygon, 6 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 6*
0 $1 to $12 corner X, Y*
0 $13 Rotation angle, in degrees counterclockwise*
0 create outline with 6 corners*
4,1,6,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$1,$2,$13*%
%AMOutline7P*
0 Free polygon, 7 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 7*
0 $1 to $14 corner X, Y*
0 $15 Rotation angle, in degrees counterclockwise*
0 create outline with 7 corners*
4,1,7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$1,$2,$15*%
%AMOutline8P*
0 Free polygon, 8 corners , with rotation*
0 The origin of the aperture is its center*
0 number of corners: always 8*
0 $1 to $16 corner X, Y*
0 $17 Rotation angle, in degrees counterclockwise*
0 create outline with 8 corners*
4,1,8,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$1,$2,$17*%
G04 Aperture macros list end*
%ADD10R,1.700000X1.700000*%
%ADD11Outline5P,-0.850000X0.510000X-0.510000X0.850000X0.850000X0.850000X0.850000X-0.850000X-0.850000X-0.850000X270.000000*%
%ADD12C,1.700000*%
%ADD13Outline5P,-0.850000X0.510000X-0.510000X0.850000X0.850000X0.850000X0.850000X-0.850000X-0.850000X-0.850000X0.000000*%
%ADD14Outline5P,-0.850000X0.510000X-0.510000X0.850000X0.850000X0.850000X0.850000X-0.850000X-0.850000X-0.850000X90.000000*%
%ADD15RoundRect,0.250000X-0.350000X0.350000X-0.350000X-0.350000X0.350000X-0.350000X0.350000X0.350000X0*%
%ADD16C,1.200000*%
%ADD17C,1.552000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J7*
X58440000Y-41450000D03*
D11*
X55900000Y-41450000D03*
D12*
X53360000Y-41450000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J1*
X84300000Y-48360000D03*
D12*
X84300000Y-50900000D03*
D10*
X84300000Y-53440000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J3*
X53050000Y-46525000D03*
D10*
X53050000Y-49065000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,J4*
X84300000Y-33625000D03*
D10*
X84300000Y-36165000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J5*
X53360000Y-54200000D03*
D14*
X55900000Y-54200000D03*
D10*
X58440000Y-54200000D03*
G04 #@! TD*
G04 #@! TO.C,J2*
X84300000Y-39710000D03*
D12*
X84300000Y-42250000D03*
X84300000Y-44790000D03*
G04 #@! TD*
D15*
G04 #@! TO.C,C1*
X58350000Y-47027401D03*
D16*
X58350000Y-49027401D03*
G04 #@! TD*
D17*
G04 #@! TO.C,U1*
X78520000Y-50830000D03*
X78520000Y-48290000D03*
X78520000Y-45750000D03*
X78520000Y-43210000D03*
X78520000Y-38130000D03*
X78520000Y-40670000D03*
X63280000Y-33050000D03*
X78520000Y-33050000D03*
X63280000Y-35590000D03*
X63280000Y-38130000D03*
X63280000Y-40670000D03*
X63280000Y-43210000D03*
X63280000Y-45750000D03*
X63280000Y-48290000D03*
X63280000Y-50830000D03*
X78520000Y-35590000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J6*
X58430000Y-33850000D03*
D12*
X55890000Y-33850000D03*
X53350000Y-33850000D03*
G04 #@! TD*
M02*
